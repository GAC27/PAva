package ist.meic.pa.GenericFunctions.Exceptions;

public class GenericFunctionIllegalArgumentException extends Exception {
	
}
